#!/bin/bash
dateFromServer=$(curl -v --insecure --silent https://google.com/ 2>&1 | grep Date | sed -e 's/< Date: //')
biji=`date +"%Y-%m-%d" -d "$dateFromServer"`
###########################
BURIQ () {
    curl -sS https://raw.githubusercontent.com/xlord27/izinvps/main/ip > /root/tmp
    data=( `cat /root/tmp | grep -E "^### " | awk '{print $2}'` )
    for user in "${data[@]}"
    do
    exp=( `grep -E "^### $user" "/root/tmp" | awk '{print $3}'` )
    d1=(`date -d "$exp" +%s`)
    d2=(`date -d "$biji" +%s`)
    exp2=$(( (d1 - d2) / 86400 ))
    if [[ "$exp2" -le "0" ]]; then
    echo $user > /etc/.$user.ini
    else
    rm -f /etc/.$user.ini > /dev/null 2>&1
    fi
    done
    rm -f /root/tmp
}

ISP=$(curl -s ipinfo.io/org | cut -d " " -f 2-10 )
CITY=$(curl -s ipinfo.io/city )
MYIP=$(curl -sS ipv4.icanhazip.com)
Name=$(curl -sS https://raw.githubusercontent.com/xlord27/izinvps/main/ip | grep $MYIP | awk '{print $2}')
echo $Name > /usr/local/etc/.$Name.ini
CekOne=$(cat /usr/local/etc/.$Name.ini)

Bloman () {
if [ -f "/etc/.$Name.ini" ]; then
CekTwo=$(cat /etc/.$Name.ini)
    if [ "$CekOne" = "$CekTwo" ]; then
        res="Expired"
    fi
else
res="Permission Accepted..."
fi
}

PERMISSION () {
    MYIP=$(curl -sS ipv4.icanhazip.com)
    IZIN=$(curl -sS https://raw.githubusercontent.com/xlord27/izinvps/main/ip | awk '{print $4}' | grep $MYIP)
    if [ "$MYIP" = "$IZIN" ]; then
    Bloman
    else
    res="Permission Denied!"
    fi
    BURIQ
}
COLOR1='\033[0;33m'
COLOR2='\033[0;39m'
red='\e[1;31m'
green='\e[1;32m'
NC='\e[0m'
green() { echo -e "\\033[32;1m${*}\\033[0m"; }
red() { echo -e "\\033[31;1m${*}\\033[0m"; }
PERMISSION

if [ "$res" = "Expired" ]; then
Exp="\e[36mExpired\033[0m"
else
Exp=$(curl -sS https://raw.githubusercontent.com/xlord27/izinvps/main/ip | grep $MYIP | awk '{print $3}')
fi
UDPX="https://docs.google.com/uc?export=download&confirm=$(wget --quiet --save-cookies /tmp/cookies.txt --keep-session-cookies --no-check-certificate 'https://docs.google.com/uc?export=download&id=1S3IE25v_fyUfCLslnujFBSBMNunDHDk2' -O- | sed -rn 's/.*confirm=([0-9A-Za-z_]+).*/\1\n/p')&id=1S3IE25v_fyUfCLslnujFBSBMNunDHDk2"
# COLOR VALIDATION
clear
BIBlack='\033[1;90m'      # Black
BIRed='\033[1;91m'        # Red
BIGreen='\033[1;92m'      # Green
BIYellow='\033[1;93m'     # Yellow
BIBlue='\033[1;94m'       # Blue
BIgreen='\033[1;95m'     # green
BIgreen='\033[1;96m'       # green
BIWhite='\033[1;97m'      # White
UWhite='\033[4;37m'       # White
On_Igreen='\033[0;105m'  #
On_IRed='\033[0;101m'
IBlack='\033[0;90m'       # Black
Red='\033[0;91m'         # Red
RED='\033[0;91'          # Red
IGreen='\033[0;92m'       # Green
IYellow='\033[0;93m'      # Yellow
IBlue='\033[0;94m'        # Blue
Igreen='\033[0;95m'      # green
green='\033[0;96m'        # green
IWhite='\033[0;97m'       # White
green='\033[0;96m'        # green
YELLOW='\033[0;93m'      # Yellow
NC='\e[0m'

UPDATE="https://raw.githubusercontent.com/xlord27/abc/main/"
BOT="https://raw.githubusercontent.com/xlord27/src/main/"
ISP=$(cat /etc/xray/isp)
NS=$(cat /etc/xray/dns)
CITY=$(cat /etc/xray/city)
IPVPS=$(curl -s ipv4.icanhazip.com)
domain=$(cat /etc/xray/domain)
RAM=$(free -m | awk 'NR==2 {print $2}')
rak=$(free -m | awk 'NR==2 {print $3}')
MEMOFREE=$(printf '%-1s' "$(free -m | awk 'NR==2{printf "%.2f%", $3*100/$2 }')")
vcp=$(printf '%-0.00001s' "$(top -bn1 | awk '/Cpu/ { cpu = "" 100 - $8 "%" }; END { print cpu }')")
MODEL=$(cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed 's/=//g' | sed 's/"//g' | sed 's/PRETTY_NAME//g')
CORE=$(printf '%-1s' "$(grep -c cpu[0-9] /proc/stat)")
Exp="LIFETIME"
Name="RizkiHdyt | Muslihudin"
DATEVPS=$(date +'%d-%m-%Y')
TIMEZONE=$(printf '%(%H:%M:%S)T')
SERONLINE=$(uptime -p | cut -d " " -f 2-10000)

nginx=$( systemctl status nginx | grep Active | awk '{print $3}' | sed 's/(//g' | sed 's/)//g' )
if [[ $nginx == "running" ]]; then
    status_nginx="${GREEN}ON${NC}"
else
    status_nginx="${RED}OFF${NC}"
fi

xray=$( systemctl status xray | grep Active | awk '{print $3}' | sed 's/(//g' | sed 's/)//g' )
if [[ $xray == "running" ]]; then
    status_xray="${GREEN}ON${NC}"
else
    status_xray="${RED}OFF${NC}"
fi

haproxy=$( systemctl status haproxy | grep Active | awk '{print $3}' | sed 's/(//g' | sed 's/)//g' )
if [[ $xray == "running" ]]; then
    status_haproxy="${GREEN}ON${NC}"
else
    status_haproxy="${RED}OFF${NC}"
fi

ttoday="$(vnstat | grep today | awk '{print $8" "substr ($9, 1, 3)}' | head -1)"
bmon="$(vnstat -m | grep date +%G-%m | awk '{print $8" "substr ($9, 1 ,3)}' | head -1)"

#KonZ
vlx=$(grep -c -E "^#vl# " "/etc/xray/config.json")
let vla=$vlx/2
vmc=$(grep -c -E "^#vm# " "/etc/xray/config.json")
let vma=$vmc/2
ssh1="$(awk -F: '$3 >= 1000 && $1 != "nobody" {print $1}' /etc/passwd | wc -l)"
trx=$(grep -c -E "^#tr# " "/etc/xray/config.json")
let trb=$trx/2
ssx=$(grep -c -E "^#ss# " "/etc/xray/config.json")
let ssa=$ssx/2

clear
echo -e "${green}╒═════════════════════════════════════════════════════════════╕\033[0m${NC}"
echo -e "\E[44;1;39m                   ⇱ SERVER INFORMATION ⇲                     \E[0m"
echo -e "${green}╘═════════════════════════════════════════════════════════════╛\033[0m${NC}"
echo -e " ${YELLOW}✪ SYSTEM OS | CPU USE ${NC} : ${green}$MODEL | CPU USE $vcp%${NC}"
echo -e " ${YELLOW}✪ SERVER RAM | USAGE ${NC}  : ${green}$RAM MB  | RAN USE $rak MB${NC}"
echo -e " ${YELLOW}✪ SERVER UPTIME ${NC}       : ${green}$SERONLINE${NC}"
echo -e " ${YELLOW}✪ DATE & TIME ${NC}         : ${green}$DATEVPS | $TIMEZONE${NC}"
echo -e " ${YELLOW}✪ DOMAIN ${NC}              : ${green}$domain${NC}"
echo -e " ${YELLOW}✪ NS DOMAIN ${NC}           : ${green}$NS${NC}"
echo -e " ${YELLOW}✪ IP VPS ${NC}              : ${green}$IPVPS${NC}"
echo -e " ${YELLOW}✪ EXP SCRIPT ${NC}          : ${green}$exp${NC}"
echo -e "${BIgreen}┌────────────────────────────────────────────────────────────┐${NC}"
echo -e "${BIgreen}│  \033[0m ${BOLD}${YELLOW}SSH     VMESS       VLESS      TROJAN       SHADOWSOCKS$NC ${BIgreen} │"
echo -e "${BIgreen}│  \033[0m ${BIgreen} $ssh1       $vma           $vla          $trb              $ssa   $NC   ${BIgreen}       │"
echo -e "${BIgreen}└────────────────────────────────────────────────────────────┘${NC}"
echo -e "     [ ${green}XRAY:${NC} ${status_xray} ]      [ ${green}NGINX:${NC} ${status_nginx} ]      [ ${green}HAPROXY:${NC} ${status_haproxy} ]"
echo -e "${green}╒═════════════════════════════════════════════════════════════╕\033[0m${NC}" | lolcat
echo -e "${BIgreen}   ┌──────────────────────┐         ┌────────────────────┐${NC}"
echo -e "     TODAY :${BIRed} $ttoday ${NC}                        MONTH :${BIRed} $bmon ${NC} "
echo -e "${BIgreen}   └──────────────────────┘         └────────────────────┘${NC}"
echo -e "${green}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m${NC}" | lolcat
echo -e "${green}╒═════════════════════════════════════════════════════════════╕\033[0m${NC}"
echo -e "\E[44;1;39m                     ⇱ MENU SERVICE ⇲                         \E[0m"
echo -e "${green}╘═════════════════════════════════════════════════════════════╛\033[0m${NC}"
echo -e " ${BIgreen}[${BIWhite}01${BIgreen}]${BIRed} •${NC} ${green}SSH MENU        $NC  ${BIgreen}[${BIWhite}11${BIgreen}]${BIRed} • ${NC}${green}CHANGE DOMAIN $NC"
echo -e " ${BIgreen}[${BIWhite}02${BIgreen}]${BIRed} •${NC} ${green}VMESS MENU      $NC  ${BIgreen}[${BIWhite}12${BIgreen}]${BIRed} • ${NC}${green}CHANGE BANNER $NC"
echo -e " ${BIgreen}[${BIWhite}03${BIgreen}]${BIRed} •${NC} ${green}VLESS MENU      $NC  ${BIgreen}[${BIWhite}13${BIgreen}]${BIRed} • ${NC}${green}RESTART SERVICE $NC"
echo -e " ${BIgreen}[${BIWhite}04${BIgreen}]${BIRed} •${NC} ${green}TROJAN MENU     $NC  ${BIgreen}[${BIWhite}14${BIgreen}]${BIRed} • ${NC}${green}RESTART SERVER $NC"
echo -e " ${BIgreen}[${BIWhite}05${BIgreen}]${BIRed} •${NC} ${green}S-SOCK MENU     $NC  ${BIgreen}[${BIWhite}15${BIgreen}]${BIRed} • ${NC}${green}INSTALL UDP  $NC"
echo -e " ${BIgreen}[${BIWhite}06${BIgreen}]${BIRed} •${NC} ${green}RUNNING SERVICE $NC  ${BIgreen}[${BIWhite}16${BIgreen}]${BIRed} • ${NC}${green}AUTO REBOOT $NC"
echo -e " ${BIgreen}[${BIWhite}07${BIgreen}]${BIRed} •${NC} ${green}BACKUP & RESTORE$NC  ${BIgreen}[${BIWhite}17${BIgreen}]${BIRed} • ${NC}${green}UPDATE SCRIPT $NC"
echo -e " ${BIgreen}[${BIWhite}08${BIgreen}]${BIRed} •${NC} ${green}INFO PORT       $NC  ${BIgreen}[${BIWhite}18${BIgreen}]${BIRed} • ${NC}${green}CLEAR EXP ACCOUNT $NC"
echo -e " ${BIgreen}[${BIWhite}09${BIgreen}]${BIRed} •${NC} ${green}VPS INFO        $NC  ${BIgreen}[${BIWhite}19${BIgreen}]${BIRed} • ${NC}${green}CLEAR LOG $NC"
echo -e " ${BIgreen}[${BIWhite}10${BIgreen}]${BIRed} •${NC} ${green}SPEEDTEST       $NC  ${BIgreen}[${BIWhite}20${BIgreen}]${BIRed} • ${NC}${green}EXIT FROM SCRIPT $NC"
echo -e "${green}╒═════════════════════════════════════════════════════════════╕\033[0m${NC}"
echo -e "\E[44;1;39m                ⇱ XLORD TUNNELING ⇲                     \E[0m"
echo -e "${green}╘═════════════════════════════════════════════════════════════╛\033[0m${NC}"
echo -e ""
read -p "Select From Options [ 1 - 20 ] : " menu
case $menu in
1) clear ;
    ssh
    ;;
2) clear ;
    vmess
    ;;
3) clear ;
    vless
    ;;
4) clear ;
    trojan
    ;;
5) clear ;
    shadowsocks
    ;;
6) clear ;
    run
    ;;
7) clear ;
    get-backres
    ;;
8) clear ;
    portin
    ;;
9) clear ;
    gotop
    ;;
10) clear ;
    clear
    speedtest
    ;;
11) clear ;
    get-domain
    ;;
12) clear ;
    nano /etc/issue.net
    ;;
13) clear ;
    seres
    ;;
14) clear ;
    reboot
    ;;

15) clear ;
    wget --load-cookies /tmp/cookies.txt ${UDPX} -O install-udp && rm -rf /tmp/cookies.txt && chmod +x install-udp && ./install-udp
    ;;
16) clear ;
    auto-reboot
    ;;
17) clear ;
    wget ${UPDATE}update.sh && chmod +x update.sh && ./update.sh
    ;;
18) clear ;
   xp
   ;;
19) clear ;
   logclean
   ;;
20) clear ;
   exit
   ;;
*)
    exit
    ;;
esac